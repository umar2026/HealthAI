import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './components/Sidebar';
import HomePage from './components/HomePage';
import DiseasePrediction from './components/DiseasePrediction';
import TreatmentPlans from './components/TreatmentPlans';
import HealthAnalytics from './components/HealthAnalytics';
import PatientChat from './components/PatientChat';

export type PageType = 
  | 'home' 
  | 'disease-prediction' 
  | 'treatment-plans' 
  | 'health-analytics' 
  | 'patient-chat';

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'disease-prediction':
        return <DiseasePrediction />;
      case 'treatment-plans':
        return <TreatmentPlans />;
      case 'health-analytics':
        return <HealthAnalytics />;
      case 'patient-chat':
        return <PatientChat />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1 ml-64 p-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

export default App;