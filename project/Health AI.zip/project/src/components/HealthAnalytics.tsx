import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, Heart, Activity, Thermometer, Droplets, AlertTriangle, CheckCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

interface HealthMetrics {
  heartRate: number[];
  bloodPressure: { systolic: number; diastolic: number }[];
  bloodSugar: number[];
  temperature: number[];
  timestamps: string[];
}

interface AnalyticsInsight {
  type: 'warning' | 'normal' | 'good';
  title: string;
  description: string;
  recommendation: string;
}

const HealthAnalytics: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<'heartRate' | 'bloodPressure' | 'bloodSugar' | 'temperature'>('heartRate');
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d'>('7d');
  const [healthData, setHealthData] = useState<HealthMetrics | null>(null);
  const [insights, setInsights] = useState<AnalyticsInsight[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Generate mock health data
  useEffect(() => {
    const generateMockData = () => {
      const days = timeRange === '24h' ? 1 : timeRange === '7d' ? 7 : 30;
      const dataPoints = timeRange === '24h' ? 24 : days;
      
      const timestamps = Array.from({ length: dataPoints }, (_, i) => {
        const date = new Date();
        if (timeRange === '24h') {
          date.setHours(date.getHours() - (dataPoints - 1 - i));
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else {
          date.setDate(date.getDate() - (dataPoints - 1 - i));
          return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        }
      });

      const heartRate = Array.from({ length: dataPoints }, () => 
        Math.floor(Math.random() * 40) + 60 // 60-100 bpm
      );

      const bloodPressure = Array.from({ length: dataPoints }, () => ({
        systolic: Math.floor(Math.random() * 40) + 110, // 110-150
        diastolic: Math.floor(Math.random() * 25) + 70   // 70-95
      }));

      const bloodSugar = Array.from({ length: dataPoints }, () => 
        Math.floor(Math.random() * 80) + 80 // 80-160 mg/dL
      );

      const temperature = Array.from({ length: dataPoints }, () => 
        (Math.random() * 2 + 97).toFixed(1) // 97-99°F
      ).map(Number);

      return {
        heartRate,
        bloodPressure,
        bloodSugar,
        temperature,
        timestamps
      };
    };

    const generateInsights = (data: HealthMetrics): AnalyticsInsight[] => {
      const avgHeartRate = data.heartRate.reduce((a, b) => a + b, 0) / data.heartRate.length;
      const avgSystolic = data.bloodPressure.reduce((a, b) => a + b.systolic, 0) / data.bloodPressure.length;
      const avgBloodSugar = data.bloodSugar.reduce((a, b) => a + b, 0) / data.bloodSugar.length;

      const insights: AnalyticsInsight[] = [];

      // Heart rate insights
      if (avgHeartRate > 90) {
        insights.push({
          type: 'warning',
          title: 'Elevated Heart Rate Detected',
          description: `Average heart rate of ${Math.round(avgHeartRate)} BPM is above normal range.`,
          recommendation: 'Consider reducing caffeine intake and managing stress levels. Consult physician if persistent.'
        });
      } else if (avgHeartRate >= 60 && avgHeartRate <= 80) {
        insights.push({
          type: 'good',
          title: 'Optimal Heart Rate',
          description: `Average heart rate of ${Math.round(avgHeartRate)} BPM is within healthy range.`,
          recommendation: 'Continue current activity level and lifestyle habits.'
        });
      }

      // Blood pressure insights
      if (avgSystolic > 130) {
        insights.push({
          type: 'warning',
          title: 'Blood Pressure Elevation',
          description: `Average systolic pressure of ${Math.round(avgSystolic)} mmHg indicates hypertension.`,
          recommendation: 'Implement DASH diet, reduce sodium intake, and increase physical activity.'
        });
      } else {
        insights.push({
          type: 'normal',
          title: 'Blood Pressure Normal',
          description: `Average systolic pressure of ${Math.round(avgSystolic)} mmHg is within normal range.`,
          recommendation: 'Maintain current lifestyle and monitor regularly.'
        });
      }

      // Blood sugar insights
      if (avgBloodSugar > 140) {
        insights.push({
          type: 'warning',
          title: 'Blood Sugar Concerns',
          description: `Average blood glucose of ${Math.round(avgBloodSugar)} mg/dL may indicate diabetes risk.`,
          recommendation: 'Schedule HbA1c test and consider dietary modifications with healthcare provider.'
        });
      } else if (avgBloodSugar <= 100) {
        insights.push({
          type: 'good',
          title: 'Excellent Glucose Control',
          description: `Average blood glucose of ${Math.round(avgBloodSugar)} mg/dL shows optimal control.`,
          recommendation: 'Continue current dietary habits and regular monitoring.'
        });
      }

      return insights;
    };

    setTimeout(() => {
      const data = generateMockData();
      setHealthData(data);
      setInsights(generateInsights(data));
      setIsLoading(false);
    }, 1000);
  }, [timeRange]);

  const getChartData = () => {
    if (!healthData) return [];

    return healthData.timestamps.map((timestamp, index) => ({
      time: timestamp,
      heartRate: healthData.heartRate[index],
      systolic: healthData.bloodPressure[index].systolic,
      diastolic: healthData.bloodPressure[index].diastolic,
      bloodSugar: healthData.bloodSugar[index],
      temperature: healthData.temperature[index]
    }));
  };

  const getMetricInfo = (metric: string) => {
    const info = {
      heartRate: { 
        name: 'Heart Rate', 
        unit: 'BPM', 
        color: '#EF4444', 
        icon: Heart,
        normal: '60-100 BPM'
      },
      bloodPressure: { 
        name: 'Blood Pressure', 
        unit: 'mmHg', 
        color: '#3B82F6', 
        icon: Activity,
        normal: '<120/80 mmHg'
      },
      bloodSugar: { 
        name: 'Blood Sugar', 
        unit: 'mg/dL', 
        color: '#10B981', 
        icon: Droplets,
        normal: '70-100 mg/dL'
      },
      temperature: { 
        name: 'Temperature', 
        unit: '°F', 
        color: '#F59E0B', 
        icon: Thermometer,
        normal: '97.7-99.5°F'
      }
    };
    return info[metric as keyof typeof info];
  };

  const vitalsOverview = healthData ? [
    {
      name: 'Heart Rate',
      value: Math.round(healthData.heartRate.reduce((a, b) => a + b, 0) / healthData.heartRate.length),
      unit: 'BPM',
      trend: 'stable',
      color: '#EF4444'
    },
    {
      name: 'Blood Pressure',
      value: `${Math.round(healthData.bloodPressure.reduce((a, b) => a + b.systolic, 0) / healthData.bloodPressure.length)}/${Math.round(healthData.bloodPressure.reduce((a, b) => a + b.diastolic, 0) / healthData.bloodPressure.length)}`,
      unit: 'mmHg',
      trend: 'improving',
      color: '#3B82F6'
    },
    {
      name: 'Blood Sugar',
      value: Math.round(healthData.bloodSugar.reduce((a, b) => a + b, 0) / healthData.bloodSugar.length),
      unit: 'mg/dL',
      trend: 'stable',
      color: '#10B981'
    },
    {
      name: 'Temperature',
      value: (healthData.temperature.reduce((a, b) => a + b, 0) / healthData.temperature.length).toFixed(1),
      unit: '°F',
      trend: 'normal',
      color: '#F59E0B'
    }
  ] : [];

  const riskDistribution = [
    { name: 'Low Risk', value: 65, color: '#10B981' },
    { name: 'Moderate Risk', value: 25, color: '#F59E0B' },
    { name: 'High Risk', value: 10, color: '#EF4444' }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-3 bg-purple-50 rounded-lg">
            <BarChart3 className="h-8 w-8 text-purple-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Health Analytics Dashboard</h1>
            <p className="text-gray-600">AI-powered health data visualization and insights</p>
          </div>
        </div>
      </motion.div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading health analytics...</p>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Controls */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
          >
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Time Range</label>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value as '24h' | '7d' | '30d')}
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="24h">Last 24 Hours</option>
                    <option value="7d">Last 7 Days</option>
                    <option value="30d">Last 30 Days</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Metric</label>
                  <select
                    value={selectedMetric}
                    onChange={(e) => setSelectedMetric(e.target.value as any)}
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    <option value="heartRate">Heart Rate</option>
                    <option value="bloodPressure">Blood Pressure</option>
                    <option value="bloodSugar">Blood Sugar</option>
                    <option value="temperature">Temperature</option>
                  </select>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Vitals Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {vitalsOverview.map((vital, index) => (
              <div key={vital.name} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-gray-600">{vital.name}</h3>
                  <TrendingUp className="h-4 w-4 text-green-500" />
                </div>
                <div className="flex items-end space-x-2">
                  <span className="text-2xl font-bold text-gray-900">{vital.value}</span>
                  <span className="text-sm text-gray-500 mb-1">{vital.unit}</span>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all duration-1000"
                      style={{ 
                        width: '70%', 
                        backgroundColor: vital.color 
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-200"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {getMetricInfo(selectedMetric).name} Trends
                  </h3>
                  <p className="text-sm text-gray-600">
                    Normal range: {getMetricInfo(selectedMetric).normal}
                  </p>
                </div>
              </div>

              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  {selectedMetric === 'bloodPressure' ? (
                    <LineChart data={getChartData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="systolic" stroke="#3B82F6" strokeWidth={2} name="Systolic" />
                      <Line type="monotone" dataKey="diastolic" stroke="#10B981" strokeWidth={2} name="Diastolic" />
                    </LineChart>
                  ) : (
                    <LineChart data={getChartData()}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey={selectedMetric} 
                        stroke={getMetricInfo(selectedMetric).color} 
                        strokeWidth={2}
                        name={getMetricInfo(selectedMetric).name}
                      />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Risk Assessment */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
            >
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Risk Assessment</h3>
              
              <div className="h-48 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-3">
                {riskDistribution.map((risk, index) => (
                  <div key={risk.name} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: risk.color }}
                      ></div>
                      <span className="text-sm text-gray-700">{risk.name}</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900">{risk.value}%</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* AI Insights */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-200"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-6">AI-Generated Health Insights</h3>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {insights.map((insight, index) => {
                const Icon = insight.type === 'warning' ? AlertTriangle : CheckCircle;
                const colorClass = insight.type === 'warning' ? 'text-red-600 bg-red-50' : 
                                 insight.type === 'good' ? 'text-green-600 bg-green-50' : 
                                 'text-blue-600 bg-blue-50';
                
                return (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <div className={`p-2 rounded-lg ${colorClass.split(' ')[1]}`}>
                        <Icon className={`h-5 w-5 ${colorClass.split(' ')[0]}`} />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-1">{insight.title}</h4>
                        <p className="text-sm text-gray-600 mb-2">{insight.description}</p>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <p className="text-sm text-gray-700">
                            <span className="font-medium">Recommendation:</span> {insight.recommendation}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default HealthAnalytics;