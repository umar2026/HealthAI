import React from 'react';
import { motion } from 'framer-motion';
import { Brain, FileText, BarChart3, MessageSquare, ArrowRight, Shield, Zap, Users } from 'lucide-react';
import { PageType } from '../App';

interface HomePageProps {
  onNavigate: (page: PageType) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const scenarios = [
    {
      id: 'disease-prediction',
      title: 'Disease Prediction',
      description: 'Advanced AI-powered symptom analysis and condition prediction using IBM Granite models.',
      icon: Brain,
      color: 'bg-blue-500',
      features: ['Symptom Analysis', 'Risk Assessment', 'Early Detection']
    },
    {
      id: 'treatment-plans',
      title: 'Treatment Plan Generator',
      description: 'Personalized treatment recommendations based on patient data and medical best practices.',
      icon: FileText,
      color: 'bg-green-500',
      features: ['Personalized Plans', 'Drug Interactions', 'Follow-up Care']
    },
    {
      id: 'health-analytics',
      title: 'Health Analytics Dashboard',
      description: 'Comprehensive health data visualization and AI-generated insights for better care decisions.',
      icon: BarChart3,
      color: 'bg-purple-500',
      features: ['Data Visualization', 'Trend Analysis', 'Predictive Insights']
    },
    {
      id: 'patient-chat',
      title: 'Patient Chat Interface',
      description: 'Intelligent conversational AI assistant for patient queries and health guidance.',
      icon: MessageSquare,
      color: 'bg-teal-500',
      features: ['24/7 Support', 'Natural Language', 'Multilingual']
    }
  ];

  const highlights = [
    {
      icon: Shield,
      title: 'Secure & Compliant',
      description: 'HIPAA-compliant data handling with end-to-end encryption'
    },
    {
      icon: Zap,
      title: 'IBM Granite Powered',
      description: 'Leveraging IBM Granite-13b-instruct-v2 for superior AI capabilities'
    },
    {
      icon: Users,
      title: 'Healthcare Focused',
      description: 'Designed specifically for healthcare professionals and patients'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          HealthAI: Intelligent Healthcare Assistant
        </h1>
        <p className="text-xl text-gray-600 mb-6 max-w-3xl mx-auto">
          Revolutionizing healthcare with AI-powered disease prediction, treatment planning, 
          and health analytics using IBM Granite's advanced language models and Watson's 
          healthcare expertise.
        </p>
        <div className="flex justify-center space-x-4">
          <button
            onClick={() => onNavigate('disease-prediction')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <span>Get Started</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </motion.div>

      {/* Key Highlights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid md:grid-cols-3 gap-6 mb-12"
      >
        {highlights.map((highlight, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-50 rounded-lg">
                <highlight.icon className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{highlight.title}</h3>
                <p className="text-sm text-gray-600">{highlight.description}</p>
              </div>
            </div>
          </div>
        ))}
      </motion.div>

      {/* Scenarios Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
          Core Healthcare Features
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {scenarios.map((scenario, index) => {
            const Icon = scenario.icon;
            return (
              <motion.div
                key={scenario.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onNavigate(scenario.id as PageType)}
              >
                <div className="flex items-start space-x-4">
                  <div className={`p-3 ${scenario.color} rounded-lg`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {scenario.title}
                    </h3>
                    <p className="text-gray-600 mb-4">{scenario.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {scenario.features.map((feature) => (
                        <span
                          key={feature}
                          className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center text-blue-600 font-medium">
                      <span>Explore Feature</span>
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Technical Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-12 bg-gradient-to-r from-blue-50 to-teal-50 p-8 rounded-xl"
      >
        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          Powered by Advanced AI Technology
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">IBM Granite Integration</h3>
            <p className="text-gray-600 mb-4">
              Leveraging IBM Granite-13b-instruct-v2 model for advanced natural language 
              processing and medical knowledge understanding.
            </p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Advanced medical reasoning capabilities</li>
              <li>• Secure, enterprise-grade AI infrastructure</li>
              <li>• Continuous learning from medical literature</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Healthcare-First Design</h3>
            <p className="text-gray-600 mb-4">
              Built with healthcare professionals' workflows in mind, ensuring 
              seamless integration with existing medical practices.
            </p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• HIPAA-compliant data processing</li>
              <li>• Medical terminology optimization</li>
              <li>• Evidence-based recommendations</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default HomePage;