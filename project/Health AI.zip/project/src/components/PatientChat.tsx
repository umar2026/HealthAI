import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, Bot, User, Clock, AlertTriangle } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'text' | 'suggestion' | 'warning';
}

const PatientChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your HealthAI assistant powered by IBM Granite. I'm here to help answer your health questions and provide guidance. How can I assist you today?",
      sender: 'ai',
      timestamp: new Date(),
      type: 'text'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickSuggestions = [
    "I have a headache and feel dizzy",
    "What should I do for high blood pressure?",
    "I'm experiencing chest pain",
    "How can I improve my sleep quality?",
    "What are the symptoms of diabetes?",
    "I need help with medication side effects"
  ];

  const generateAIResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('headache') || lowerMessage.includes('dizzy')) {
      return "I understand you're experiencing headaches and dizziness. These symptoms can have various causes including dehydration, stress, or more serious conditions. Here's what I recommend:\n\n• Stay hydrated and rest in a quiet, dark room\n• Avoid triggers like bright lights or loud sounds\n• Consider over-the-counter pain relief if appropriate\n• Monitor your symptoms\n\n⚠️ If symptoms persist, worsen, or you experience severe headache with neck stiffness, confusion, or vision changes, please seek immediate medical attention.";
    }
    
    if (lowerMessage.includes('chest pain')) {
      return "⚠️ IMPORTANT: Chest pain can be a serious symptom that requires immediate medical evaluation.\n\nPlease seek emergency medical care if you're experiencing:\n• Severe or crushing chest pain\n• Pain radiating to arm, jaw, or back\n• Shortness of breath\n• Sweating or nausea\n• Dizziness or fainting\n\nIf your chest pain is mild and you suspect it might be related to muscle strain or acid reflux, you should still consult with a healthcare provider for proper evaluation. Don't delay seeking medical care for chest pain.";
    }
    
    if (lowerMessage.includes('blood pressure') || lowerMessage.includes('hypertension')) {
      return "Managing high blood pressure is important for your cardiovascular health. Here are evidence-based recommendations:\n\n🍎 **Dietary Changes:**\n• Follow the DASH diet (rich in fruits, vegetables, whole grains)\n• Reduce sodium intake to less than 2,300mg daily\n• Limit processed foods and added sugars\n\n🏃 **Lifestyle Modifications:**\n• Aim for 150 minutes of moderate exercise weekly\n• Maintain a healthy weight\n• Limit alcohol consumption\n• Quit smoking if applicable\n\n📊 **Monitoring:**\n• Check blood pressure regularly\n• Keep a log of readings\n• Take medications as prescribed\n\nPlease work with your healthcare provider to develop a personalized treatment plan.";
    }
    
    if (lowerMessage.includes('sleep') || lowerMessage.includes('insomnia')) {
      return "Good sleep hygiene is crucial for overall health. Here are some strategies to improve your sleep quality:\n\n🌙 **Sleep Environment:**\n• Keep bedroom cool, dark, and quiet\n• Use comfortable mattress and pillows\n• Remove electronic devices before bedtime\n\n⏰ **Sleep Schedule:**\n• Go to bed and wake up at consistent times\n• Avoid long daytime naps\n• Create a relaxing bedtime routine\n\n🥗 **Lifestyle Factors:**\n• Avoid caffeine 6 hours before bedtime\n• Don't eat large meals close to bedtime\n• Exercise regularly, but not close to bedtime\n\nIf sleep problems persist for more than 2-3 weeks, consider consulting a healthcare provider to rule out sleep disorders.";
    }
    
    if (lowerMessage.includes('diabetes') || lowerMessage.includes('blood sugar')) {
      return "Diabetes symptoms and management are important to understand. Here's key information:\n\n🔍 **Common Diabetes Symptoms:**\n• Frequent urination and excessive thirst\n• Unexplained weight loss\n• Extreme fatigue\n• Blurred vision\n• Slow-healing wounds\n• Frequent infections\n\n📋 **Type 2 Diabetes Management:**\n• Monitor blood glucose levels regularly\n• Follow a balanced, carbohydrate-controlled diet\n• Exercise regularly (30+ minutes daily)\n• Take medications as prescribed\n• Attend regular check-ups\n\n⚠️ Seek immediate medical attention if you experience severe symptoms like vomiting, difficulty breathing, or blood sugar levels >400 mg/dL.\n\nPlease consult with an endocrinologist or primary care physician for proper diagnosis and treatment planning.";
    }
    
    if (lowerMessage.includes('medication') || lowerMessage.includes('side effect')) {
      return "Medication side effects are a common concern. Here's how to handle them:\n\n📋 **Common Side Effects to Monitor:**\n• Nausea, dizziness, or fatigue\n• Changes in appetite or sleep\n• Skin reactions or rashes\n• Mood changes\n\n⚠️ **When to Contact Your Doctor:**\n• Severe or persistent side effects\n• Allergic reactions (rash, swelling, difficulty breathing)\n• Unusual symptoms not listed on medication information\n\n💡 **General Tips:**\n• Never stop medications abruptly without medical guidance\n• Keep a medication diary\n• Take medications exactly as prescribed\n• Inform all healthcare providers about current medications\n\nAlways discuss side effects with your prescribing physician or pharmacist for personalized advice.";
    }
    
    return "Thank you for your question. While I can provide general health information, I want to emphasize that I'm an AI assistant and cannot replace professional medical advice.\n\nFor the most accurate assessment of your specific situation, I recommend:\n• Consulting with your primary care physician\n• Seeking emergency care if you have urgent symptoms\n• Keeping a symptom diary to share with healthcare providers\n\nIs there any other general health information I can help you with today?";
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    const aiResponse: Message = {
      id: (Date.now() + 1).toString(),
      text: generateAIResponse(inputText),
      sender: 'ai',
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, aiResponse]);
    setIsTyping(false);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputText(suggestion);
  };

  const formatMessageText = (text: string) => {
    return text.split('\n').map((line, index) => {
      if (line.startsWith('⚠️')) {
        return (
          <div key={index} className="bg-red-50 border border-red-200 rounded-lg p-3 my-2">
            <div className="flex items-start space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
              <span className="text-red-800 font-medium">{line.replace('⚠️', '').trim()}</span>
            </div>
          </div>
        );
      }
      
      if (line.startsWith('•')) {
        return (
          <div key={index} className="flex items-start space-x-2 my-1">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
            <span>{line.replace('•', '').trim()}</span>
          </div>
        );
      }
      
      if (line.includes('**') && line.includes(':')) {
        const [label, ...rest] = line.split(':');
        return (
          <div key={index} className="my-2">
            <span className="font-semibold text-gray-900">
              {label.replace(/\*\*/g, '')}:
            </span>
            <span className="text-gray-700">{rest.join(':')}</span>
          </div>
        );
      }
      
      return <div key={index} className="my-1">{line}</div>;
    });
  };

  return (
    <div className="max-w-4xl mx-auto h-screen flex flex-col">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-3 bg-teal-50 rounded-lg">
            <MessageSquare className="h-8 w-8 text-teal-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Patient Chat Interface</h1>
            <p className="text-gray-600">24/7 AI health assistant powered by IBM Granite</p>
          </div>
        </div>
      </motion.div>

      {/* Chat Container */}
      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col">
        {/* Chat Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-teal-100 rounded-full">
              <Bot className="h-6 w-6 text-teal-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">HealthAI Assistant</h3>
              <div className="flex items-center space-x-1 text-sm text-green-600">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Online</span>
              </div>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-3 max-w-3xl ${
                  message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <div className={`p-2 rounded-full ${
                    message.sender === 'user' 
                      ? 'bg-blue-100' 
                      : 'bg-teal-100'
                  }`}>
                    {message.sender === 'user' ? (
                      <User className="h-5 w-5 text-blue-600" />
                    ) : (
                      <Bot className="h-5 w-5 text-teal-600" />
                    )}
                  </div>
                  <div className={`p-4 rounded-xl ${
                    message.sender === 'user'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}>
                    <div className="text-sm leading-relaxed">
                      {message.sender === 'user' ? message.text : formatMessageText(message.text)}
                    </div>
                    <div className={`flex items-center space-x-1 mt-2 text-xs ${
                      message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      <Clock className="h-3 w-3" />
                      <span>{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="flex items-start space-x-3 max-w-3xl">
                <div className="p-2 bg-teal-100 rounded-full">
                  <Bot className="h-5 w-5 text-teal-600" />
                </div>
                <div className="p-4 bg-gray-100 rounded-xl">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="p-4 border-t border-gray-200 bg-gray-50">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Questions:</h4>
            <div className="flex flex-wrap gap-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="text-sm bg-white border border-gray-200 rounded-full px-3 py-2 hover:bg-gray-50 hover:border-teal-300 transition-colors"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-3">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your health question here..."
              className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              disabled={isTyping}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputText.trim() || isTyping}
              className="bg-teal-600 text-white p-3 rounded-lg hover:bg-teal-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          
          <div className="mt-3 text-xs text-gray-500 text-center">
            This AI assistant provides general health information only. For medical emergencies, call emergency services immediately.
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientChat;