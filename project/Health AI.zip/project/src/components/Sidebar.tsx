import React from 'react';
import { 
  Home, 
  Brain, 
  FileText, 
  BarChart3, 
  MessageSquare, 
  Activity
} from 'lucide-react';
import { PageType } from '../App';

interface SidebarProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate }) => {
  const menuItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'disease-prediction', label: 'Disease Prediction', icon: Brain },
    { id: 'treatment-plans', label: 'Treatment Plans', icon: FileText },
    { id: 'health-analytics', label: 'Health Analytics', icon: BarChart3 },
    { id: 'patient-chat', label: 'Patient Chat', icon: MessageSquare },
  ];

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg border-r border-gray-200 z-10">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Activity className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">HealthAI</h1>
            <p className="text-sm text-gray-500">IBM Granite Powered</p>
          </div>
        </div>
      </div>

      <nav className="px-4 pb-6">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id as PageType)}
                className={`flex items-center space-x-3 w-full p-3 text-left rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 shadow-sm'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon className={`h-5 w-5 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;