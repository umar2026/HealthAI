import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, User, Pill, Activity, Calendar, AlertCircle, CheckCircle2 } from 'lucide-react';

interface TreatmentPlan {
  condition: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
    instructions: string;
  }>;
  lifestyle: string[];
  followUp: Array<{
    type: string;
    timeframe: string;
    description: string;
  }>;
  monitoring: string[];
  warnings: string[];
}

const TreatmentPlans: React.FC = () => {
  const [patientData, setPatientData] = useState({
    condition: '',
    age: '',
    weight: '',
    allergies: '',
    currentMedications: '',
    medicalHistory: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [treatmentPlan, setTreatmentPlan] = useState<TreatmentPlan | null>(null);

  const commonConditions = [
    'Hypertension', 'Type 2 Diabetes', 'Asthma', 'Depression', 'Anxiety',
    'Arthritis', 'COPD', 'Heart Disease', 'Migraine', 'Insomnia'
  ];

  const generateTreatmentPlan = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    // Mock treatment plan based on condition
    const mockPlans: { [key: string]: TreatmentPlan } = {
      'Hypertension': {
        condition: 'Hypertension (High Blood Pressure)',
        medications: [
          {
            name: 'Lisinopril',
            dosage: '10 mg',
            frequency: 'Once daily',
            duration: 'Ongoing',
            instructions: 'Take in the morning with or without food'
          },
          {
            name: 'Hydrochlorothiazide',
            dosage: '25 mg',
            frequency: 'Once daily',
            duration: 'Ongoing',
            instructions: 'Take with food to reduce stomach upset'
          }
        ],
        lifestyle: [
          'Reduce sodium intake to less than 2,300mg daily',
          'Engage in 150 minutes of moderate exercise weekly',
          'Maintain healthy weight (BMI 18.5-24.9)',
          'Limit alcohol consumption',
          'Practice stress management techniques',
          'Quit smoking if applicable'
        ],
        followUp: [
          {
            type: 'Blood Pressure Check',
            timeframe: '2 weeks',
            description: 'Monitor response to initial medication'
          },
          {
            type: 'Comprehensive Review',
            timeframe: '3 months',
            description: 'Assess overall treatment effectiveness'
          }
        ],
        monitoring: [
          'Daily blood pressure readings',
          'Weekly weight measurements',
          'Monthly medication adherence review'
        ],
        warnings: [
          'Contact physician if systolic BP >180 or diastolic >110',
          'Report any dizziness, fainting, or unusual fatigue',
          'Avoid sudden discontinuation of medications'
        ]
      },
      'Type 2 Diabetes': {
        condition: 'Type 2 Diabetes Mellitus',
        medications: [
          {
            name: 'Metformin',
            dosage: '500 mg',
            frequency: 'Twice daily',
            duration: 'Ongoing',
            instructions: 'Take with meals to reduce GI side effects'
          }
        ],
        lifestyle: [
          'Follow carbohydrate-controlled diet',
          'Monitor blood glucose levels regularly',
          'Exercise 30 minutes most days of the week',
          'Maintain healthy weight',
          'Annual eye and foot examinations'
        ],
        followUp: [
          {
            type: 'HbA1c Test',
            timeframe: '3 months',
            description: 'Monitor long-term glucose control'
          },
          {
            type: 'Diabetes Education',
            timeframe: '1 month',
            description: 'Comprehensive diabetes management training'
          }
        ],
        monitoring: [
          'Daily blood glucose monitoring',
          'Weekly weight tracking',
          'Quarterly HbA1c levels'
        ],
        warnings: [
          'Seek immediate care if blood glucose <70 or >400 mg/dL',
          'Watch for signs of diabetic ketoacidosis',
          'Report persistent nausea or vomiting'
        ]
      }
    };

    const selectedPlan = mockPlans[patientData.condition] || mockPlans['Hypertension'];
    setTreatmentPlan(selectedPlan);
    setIsLoading(false);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-3 bg-green-50 rounded-lg">
            <FileText className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Treatment Plan Generator</h1>
            <p className="text-gray-600">Personalized treatment recommendations powered by AI</p>
          </div>
        </div>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Patient Input Form */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-1"
        >
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 sticky top-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center space-x-2">
              <User className="h-5 w-5 text-gray-600" />
              <span>Patient Information</span>
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Primary Condition</label>
                <select
                  value={patientData.condition}
                  onChange={(e) => setPatientData({...patientData, condition: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">Select condition</option>
                  {commonConditions.map(condition => (
                    <option key={condition} value={condition}>{condition}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
                  <input
                    type="number"
                    value={patientData.age}
                    onChange={(e) => setPatientData({...patientData, age: e.target.value})}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Years"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Weight</label>
                  <input
                    type="number"
                    value={patientData.weight}
                    onChange={(e) => setPatientData({...patientData, weight: e.target.value})}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="kg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Known Allergies</label>
                <textarea
                  value={patientData.allergies}
                  onChange={(e) => setPatientData({...patientData, allergies: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  rows={2}
                  placeholder="List any known allergies"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Current Medications</label>
                <textarea
                  value={patientData.currentMedications}
                  onChange={(e) => setPatientData({...patientData, currentMedications: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  rows={2}
                  placeholder="List current medications"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Medical History</label>
                <textarea
                  value={patientData.medicalHistory}
                  onChange={(e) => setPatientData({...patientData, medicalHistory: e.target.value})}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  rows={3}
                  placeholder="Relevant medical history"
                />
              </div>

              <button
                onClick={generateTreatmentPlan}
                disabled={!patientData.condition || isLoading}
                className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Generating...</span>
                  </>
                ) : (
                  <>
                    <FileText className="h-5 w-5" />
                    <span>Generate Plan</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>

        {/* Treatment Plan Results */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2"
        >
          {!treatmentPlan && !isLoading && (
            <div className="bg-white p-12 rounded-xl shadow-sm border border-gray-200 text-center">
              <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-semibold text-gray-400 mb-2">No Treatment Plan Generated</h3>
              <p className="text-gray-500">Fill out the patient information form to generate a personalized treatment plan</p>
            </div>
          )}

          {isLoading && (
            <div className="bg-white p-12 rounded-xl shadow-sm border border-gray-200 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Generating personalized treatment plan...</p>
            </div>
          )}

          {treatmentPlan && (
            <div className="space-y-6">
              {/* Header */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{treatmentPlan.condition}</h2>
                <p className="text-gray-600">Comprehensive treatment plan generated by AI</p>
              </div>

              {/* Medications */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Pill className="h-6 w-6 text-blue-600" />
                  <h3 className="text-xl font-semibold text-gray-900">Medications</h3>
                </div>
                <div className="space-y-4">
                  {treatmentPlan.medications.map((medication, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-lg text-gray-900">{medication.name}</h4>
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                          {medication.dosage}
                        </span>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>
                          <span className="font-medium">Frequency:</span> {medication.frequency}
                        </div>
                        <div>
                          <span className="font-medium">Duration:</span> {medication.duration}
                        </div>
                      </div>
                      <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium text-gray-700">Instructions:</span>
                        <p className="text-gray-600 mt-1">{medication.instructions}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Lifestyle Recommendations */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Activity className="h-6 w-6 text-green-600" />
                  <h3 className="text-xl font-semibold text-gray-900">Lifestyle Modifications</h3>
                </div>
                <ul className="space-y-3">
                  {treatmentPlan.lifestyle.map((item, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Follow-up Care */}
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Calendar className="h-6 w-6 text-purple-600" />
                  <h3 className="text-xl font-semibold text-gray-900">Follow-up Schedule</h3>
                </div>
                <div className="space-y-4">
                  {treatmentPlan.followUp.map((followUp, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{followUp.type}</h4>
                        <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
                          {followUp.timeframe}
                        </span>
                      </div>
                      <p className="text-gray-600">{followUp.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Monitoring & Warnings */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Monitoring Requirements</h3>
                  <ul className="space-y-2">
                    {treatmentPlan.monitoring.map((item, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700 text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center space-x-2 mb-4">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Important Warnings</h3>
                  </div>
                  <ul className="space-y-2">
                    {treatmentPlan.warnings.map((warning, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-2 h-2 bg-red-600 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700 text-sm">{warning}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Disclaimer */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="h-6 w-6 text-yellow-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-yellow-800 mb-2">Medical Disclaimer</h3>
                    <p className="text-yellow-700 text-sm">
                      This AI-generated treatment plan is for informational purposes only and should not replace 
                      professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare 
                      providers before starting, stopping, or changing any medical treatment. Individual patient 
                      factors may require plan modifications.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default TreatmentPlans;